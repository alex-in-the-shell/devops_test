# Safeboard
Локальный стенд с Uptime Kuma, MariaDB и мониторингом через Prometheus и Grafana. Все сервисы запускаются через Dagger и Docker Engine

## Состав
В `compose.app.yaml` описаны Uptime Kuma 2 и MariaDB 11.8. Данные сохраняются в именованных томах. Отдельный файл `compose.monitoring.yaml` поднимает Prometheus, Grafana и экспортеры метрик

Команды Dagger находятся в `main.py`, а дашборд Grafana — в `monitoring/grafana/dashboards/safeboard-overview.json`. Kuma подключается к MariaDB как к внешней базе

## Перед запуском
Нужны Docker Engine или Docker Desktop с Compose v2 и Dagger CLI `v0.21.11`. Dagger должен видеть Docker socket `/var/run/docker.sock`. Для Docker Desktop проверьте доступ к сокету из среды Dagger

Скопируйте шаблон переменных и замените четыре заглушки `password` разными паролями:

```sh
cp .env.example .env
```

Затем создайте Python SDK для Dagger:

```sh
dagger develop --sdk=python
```

Файл `.env` остается у вас и в архив не включен

## Запуск
Поднять оба контура и настроить Grafana можно одной командой:

```sh
dagger call deploy-all
```

Если нужно запустить части отдельно:

```sh
dagger call deploy-app
dagger call deploy-monitoring
dagger call configure-grafana
```

`configure-grafana` добавляет Prometheus как источник данных и загружает дашборд. Пароль Grafana берется из `.env`

Kuma будет доступна на [localhost:3001](http://localhost:3001), Grafana — на [localhost:3000](http://localhost:3000), Prometheus — на [localhost:9090](http://localhost:9090). Для входа в Grafana используйте `admin` и значение `GRAFANA_ADMIN_PASSWORD`. Дашборд называется **Safeboard — обзор стенда**

В Prometheus можно проверить доступность Kuma и MariaDB, а также состояние экспортеров:

```promql
probe_success{job="uptime-kuma"} or vector(0)
max(mysql_up) or vector(0)
up{job="cadvisor"}
up{job="node-exporter"}
```

Для первых двух запросов `1` означает, что сервис доступен, `0` — что нет. Запросы `up` показывают, видит ли Prometheus соответствующий экспортер

Состояние контейнеров:

```sh
docker compose --project-name safeboard-app --file compose.app.yaml ps
docker compose --project-name safeboard-monitoring --file compose.monitoring.yaml ps
```

## Проверка отказа
Команда остановит MariaDB, дождется, пока Prometheus отметит ее недоступной, а затем проверит восстановление и автоматический перезапуск контейнера:

```sh
dagger call chaos-test
```

Prometheus опрашивает сервисы раз в 15 секунд. На обнаружение отказа и восстановления отводится до трех циклов опроса, на проверку автоперезапуска — до 30 секунд

## Docker Desktop на macOS
Docker Desktop запускает контейнеры в Linux VM. Поэтому node exporter и cAdvisor показывают метрики этой VM, а не самой macOS. На Linux они собирают метрики Docker-хоста

## Остановка
```sh
docker compose --project-name safeboard-app --file compose.app.yaml down
docker compose --project-name safeboard-monitoring --file compose.monitoring.yaml down
```

Данные останутся в томах. Чтобы удалить их, добавьте `--volumes` к обеим командам
