import asyncio
import json
import shlex
from urllib.parse import quote

import dagger
from dagger import dag, function, object_type


NETWORK = "safeboard"
APP_PROJECT = "safeboard-app"
MONITORING_PROJECT = "safeboard-monitoring"
GRAFANA_UID = "prometheus"
GRAFANA_DASHBOARD_UID = "safeboard-overview"
SCRAPE_INTERVAL_SECONDS = 15
MARIADB_STATUS_QUERY = "max(mysql_up) or vector(0)"
KUMA_STATUS_QUERY = 'probe_success{job="uptime-kuma"} or vector(0)'


@object_type
class Safeboard:
    def docker_cli(self, source: dagger.Directory) -> dagger.Container:
        return (
            dag.container()
            .from_("alpine:3.22")
            .with_exec(["apk", "add", "--no-cache", "docker-cli", "docker-cli-compose"])
            .with_mounted_socket(
                "/var/run/docker.sock",
                dag.host().unix_socket("/var/run/docker.sock"),
            )
            .with_directory("/workspace", source)
            .with_workdir("/workspace")
        )

    async def compose(
        self,
        source: dagger.Directory,
        compose_file: str,
        project: str,
        *args: str,
    ) -> str:
        cli = self.docker_cli(source)
        return await (
            cli.with_exec(
                [
                    "sh",
                    "-c",
                    f"docker network inspect {NETWORK} >/dev/null 2>&1 || docker network create {NETWORK} >/dev/null 2>&1 || docker network inspect {NETWORK} >/dev/null",
                ]
            )
            .with_exec(
                [
                    "docker",
                    "compose",
                    "--project-name",
                    project,
                    "--project-directory",
                    "/workspace",
                    "--file",
                    compose_file,
                    *args,
                ]
            )
            .stdout()
        )

    async def request_grafana(
        self,
        source: dagger.Directory,
        password: str,
        path: str,
        method: str = "GET",
        payload: str = "",
    ) -> str:
        runner = (
            self.docker_cli(source)
            .with_env_variable("GRAFANA_ADMIN_USER", "admin")
            .with_secret_variable(
                "GRAFANA_ADMIN_PASSWORD",
                dag.set_secret("grafana-admin-password", password),
            )
        )
        command = [
            "docker",
            "run",
            "--rm",
            "--interactive",
            "--network",
            NETWORK,
            "--env",
            "GRAFANA_ADMIN_USER",
            "--env",
            "GRAFANA_ADMIN_PASSWORD",
            "--entrypoint",
            "sh",
            "curlimages/curl:8.14.0",
            "-c",
            (
                'umask 077; printf "machine grafana login %s password %s\\n" "$GRAFANA_ADMIN_USER" "$GRAFANA_ADMIN_PASSWORD" > /tmp/grafana.netrc; '
                'curl --silent --show-error --connect-timeout 3 --max-time 5 --output /dev/null --write-out "%{http_code}" '
                "--netrc-file /tmp/grafana.netrc "
                f"--request {shlex.quote(method)} "
                '--header "Content-Type: application/json" '
                + ("--data-binary @- " if payload else "")
                + shlex.quote(f"http://grafana:3000{path}")
            ),
        ]
        result = await runner.with_exec(command, stdin=payload).stdout()
        return result.strip()

    async def prometheus_query(
        self,
        source: dagger.Directory,
        query: str,
    ) -> dict:
        cli = self.docker_cli(source)
        result = await cli.with_exec(
            [
                "docker",
                "run",
                "--rm",
                "--network",
                NETWORK,
                "--entrypoint",
                "sh",
                "curlimages/curl:8.14.0",
                "-c",
                f'curl --fail --silent --show-error --connect-timeout 3 --max-time 5 "http://prometheus:9090/api/v1/query?query={quote(query, safe="")}"',
            ]
        ).stdout()
        return json.loads(result)

    @staticmethod
    def env_value(contents: str, name: str) -> str:
        for line in contents.splitlines():
            key, separator, value = line.partition("=")
            if separator and key.strip() == name:
                value = value.strip()
                if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                    value = value[1:-1]
                if value:
                    return value
        raise ValueError(f"{name} is missing from .env")

    async def metric_value(self, source: dagger.Directory, query: str) -> float | None:
        response = await self.prometheus_query(source, query)
        values = response.get("data", {}).get("result", [])
        if not values:
            return None
        return float(values[0]["value"][1])

    async def mariadb_restart_count(self, cli: dagger.Container) -> int:
        container_id = await cli.with_exec(
            [
                "docker",
                "compose",
                "--project-name",
                APP_PROJECT,
                "--file",
                "compose.app.yaml",
                "ps",
                "--all",
                "--quiet",
                "mariadb",
            ]
        ).stdout()
        if not container_id.strip():
            raise RuntimeError("MariaDB container was not found")
        result = await cli.with_exec(
            ["docker", "inspect", "--format", "{{.RestartCount}}", container_id.strip()]
        ).stdout()
        return int(result)

    @function
    async def deploy_app(
        self,
        # +defaultPath="."
        source: dagger.Directory,
    ) -> str:
        return await self.compose(
            source, "compose.app.yaml", APP_PROJECT, "up", "--detach", "--wait"
        )

    @function
    async def deploy_monitoring(
        self,
        # +defaultPath="."
        source: dagger.Directory,
    ) -> str:
        return await self.compose(
            source,
            "compose.monitoring.yaml",
            MONITORING_PROJECT,
            "up",
            "--detach",
            "--wait",
        )

    @function
    async def configure_grafana(
        self,
        # +defaultPath="."
        source: dagger.Directory,
    ) -> str:
        await self.deploy_monitoring(source)
        env_contents = await source.file(".env").contents()
        password = self.env_value(env_contents, "GRAFANA_ADMIN_PASSWORD")
        for _ in range(15):
            status = await self.request_grafana(source, password, "/api/health")
            if status == "200":
                break
            await asyncio.sleep(2)
        else:
            raise RuntimeError("Grafana API did not become ready")

        datasource = json.dumps(
            {
                "uid": GRAFANA_UID,
                "name": "Prometheus",
                "type": "prometheus",
                "access": "proxy",
                "url": "http://prometheus:9090",
                "isDefault": True,
                "editable": False,
            }
        )
        status = await self.request_grafana(
            source,
            password,
            f"/api/datasources/uid/{GRAFANA_UID}",
        )
        if status == "404":
            status = await self.request_grafana(
                source,
                password,
                "/api/datasources",
                method="POST",
                payload=datasource,
            )
            if status == "409":
                status = await self.request_grafana(
                    source,
                    password,
                    f"/api/datasources/uid/{GRAFANA_UID}",
                    method="PUT",
                    payload=datasource,
                )
        else:
            status = await self.request_grafana(
                source,
                password,
                f"/api/datasources/uid/{GRAFANA_UID}",
                method="PUT",
                payload=datasource,
            )
        if not status.startswith("2"):
            raise RuntimeError(f"Grafana data source API returned HTTP {status}")

        dashboard = json.loads(
            await source.file(
                "monitoring/grafana/dashboards/safeboard-overview.json"
            ).contents()
        )
        dashboard["uid"] = GRAFANA_DASHBOARD_UID
        payload = json.dumps({"dashboard": dashboard, "folderId": 0, "overwrite": True})
        status = await self.request_grafana(
            source,
            password,
            "/api/dashboards/db",
            method="POST",
            payload=payload,
        )
        if not status.startswith("2"):
            raise RuntimeError(f"Grafana dashboard API returned HTTP {status}")
        return "Grafana data source and Safeboard overview dashboard configured"

    @function
    async def deploy_all(
        self,
        # +defaultPath="."
        source: dagger.Directory,
    ) -> str:
        app_result = await self.deploy_app(source)
        monitoring_result = await self.deploy_monitoring(source)
        grafana_result = await self.configure_grafana(source)
        await self.docker_cli(source).with_exec(
            [
                "docker",
                "run",
                "--rm",
                "--network",
                NETWORK,
                "--entrypoint",
                "sh",
                "curlimages/curl:8.14.0",
                "-c",
                "curl --fail --silent --show-error --max-time 5 http://uptime-kuma:3001/ >/dev/null",
            ]
        ).stdout()
        for job in ("prometheus", "cadvisor", "node-exporter", "mariadb"):
            for _ in range(6):
                value = await self.metric_value(source, f'up{{job="{job}"}}')
                if value == 1:
                    break
                await asyncio.sleep(5)
            else:
                raise RuntimeError(f"Prometheus target {job} did not become healthy")
        for query in (MARIADB_STATUS_QUERY, KUMA_STATUS_QUERY):
            for _ in range(6):
                if await self.metric_value(source, query) == 1:
                    break
                await asyncio.sleep(5)
            else:
                raise RuntimeError(f"Prometheus query did not report healthy: {query}")
        return "\n".join(
            [
                app_result.strip(),
                monitoring_result.strip(),
                grafana_result,
                "Prometheus, Grafana, MariaDB, exporters and Uptime Kuma are healthy",
            ]
        )

    @function
    async def chaos_test(
        self,
        # +defaultPath="."
        source: dagger.Directory,
    ) -> str:
        await self.deploy_all(source)
        cli = self.docker_cli(source)
        await cli.with_exec(
            [
                "docker",
                "compose",
                "--project-name",
                APP_PROJECT,
                "--file",
                "compose.app.yaml",
                "stop",
                "mariadb",
            ]
        ).stdout()

        down_seen = False
        for _ in range(3):
            await asyncio.sleep(SCRAPE_INTERVAL_SECONDS)
            if await self.metric_value(source, MARIADB_STATUS_QUERY) == 0:
                down_seen = True
                break
        if not down_seen:
            raise RuntimeError("Prometheus did not observe MariaDB as down")

        await cli.with_exec(
            [
                "docker",
                "compose",
                "--project-name",
                APP_PROJECT,
                "--file",
                "compose.app.yaml",
                "start",
                "mariadb",
            ]
        ).stdout()
        await cli.with_exec(
            [
                "docker",
                "compose",
                "--project-name",
                APP_PROJECT,
                "--file",
                "compose.app.yaml",
                "up",
                "--detach",
                "--wait",
                "mariadb",
            ]
        ).stdout()
        for _ in range(3):
            await asyncio.sleep(SCRAPE_INTERVAL_SECONDS)
            if await self.metric_value(source, MARIADB_STATUS_QUERY) == 1:
                break
        else:
            raise RuntimeError("Prometheus did not observe MariaDB recovery")

        before = await self.mariadb_restart_count(cli)
        await cli.with_exec(
            [
                "docker",
                "compose",
                "--project-name",
                APP_PROJECT,
                "--file",
                "compose.app.yaml",
                "kill",
                "mariadb",
            ]
        ).stdout()
        restarted = False
        for _ in range(6):
            await asyncio.sleep(5)
            after = await self.mariadb_restart_count(cli)
            if after > before:
                restarted = True
                break
        if not restarted:
            raise RuntimeError(
                "MariaDB restart policy did not restart the killed container"
            )
        await cli.with_exec(
            [
                "docker",
                "compose",
                "--project-name",
                APP_PROJECT,
                "--file",
                "compose.app.yaml",
                "up",
                "--detach",
                "--wait",
                "mariadb",
            ]
        ).stdout()
        for _ in range(6):
            await asyncio.sleep(5)
            if await self.metric_value(source, MARIADB_STATUS_QUERY) == 1:
                break
        else:
            raise RuntimeError(
                "Prometheus did not observe MariaDB after restart-policy recovery"
            )
        return "Grafana-backed Prometheus metrics observed the database outage and recovery; restart policy also recovered MariaDB"
